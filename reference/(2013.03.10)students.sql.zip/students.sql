-- phpMyAdmin SQL Dump
-- version 2.11.5.1
-- http://www.phpmyadmin.net
--
-- 호스트: localhost
-- 처리한 시간: 13-03-10 02:27 
-- 서버 버전: 5.1.45
-- PHP 버전: 5.2.9p2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- 데이터베이스: `jjyking2`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL,
  `pic_url` varchar(128) DEFAULT NULL,
  `floor` tinyint(2) DEFAULT NULL,
  `program` varchar(8) DEFAULT NULL,
  `research_group` varchar(32) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- 테이블의 덤프 데이터 `students`
--

INSERT INTO `students` (`id`, `name`, `pic_url`, `floor`, `program`, `research_group`, `status`) VALUES
(1, 'H.D. Bae', '/profile_hdbae.jpg', 2, 'MS', 'Mobile', 1),
(2, 'C.K. Hong', '/profile_ckhong.jpg', 2, 'Ph.D', 'System Biology', 1),
(3, 'H.S. Chwa', '/profile_hschwa.jpg', 4, 'Ph.D', 'Realtime', 1),
(4, 'H.S. Kim', '/profile_hskim.jpg', 4, 'Ph.D', 'Mobile', 1),
(5, 'K.H. Lee', '/profile_khlee.jpg', 4, 'Ph.D', 'Network', 1),
(6, 'H.B. Baek', '/profile_hbbaek.jpg', 2, 'Ph.D', 'Realtime', 0),
(7, 'J.B. Seo', '/profile_jbseo.jpg', 2, 'Ph.D', 'Virtualization', 1),
(8, 'W.H. Han', '/profile_whhan.jpg', 4, 'Ph.D', 'GPU', 1),
(9, 'J.W. Lee', '/profile_not_found.jpg', 4, 'Ph.D', 'Realtime', 1),
(10, 'J.Y. Lee', '/profile_jylee.jpg', 4, 'MS', 'Realtime', 1),
(11, 'S.E. Oh', '/profile_seoh.jpg', 4, 'MS', 'GPU', 1),
(12, 'H.D. Bui', '/profile_hdbui.jpg', 4, 'MS', 'Network', 1),
(13, 'P.K. My', '/profile_pkmy.jpg', 4, 'BS', 'Realtime', 1);
